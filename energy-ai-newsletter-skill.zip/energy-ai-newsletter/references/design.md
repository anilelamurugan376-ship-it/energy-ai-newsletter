# 设计规范 · Design Reference

## 色彩系统

### Header 背景（按主题选择）

| 主题类型 | 背景色 |
|---------|--------|
| 运营/效率 | `#042C53`（深蓝，默认） |
| 案例/故事 | `#173404`（深绿） |
| 海外视角 | `linear-gradient(135deg,#1a1a2e,#0f3460)`（深夜蓝） |
| 政策合规 | `#2C1810`（深棕） |
| 营销/用户 | `linear-gradient(135deg,#042C53,#0C5C2A)`（蓝绿渐变） |

### 新闻标签配色

| 标签类型 | 背景 | 文字 |
|---------|------|------|
| 行业案例 / 产品动态 | `#E6F1FB` | `#0C447C` |
| 国内动态 / 数据洞察 | `#EAF3DE` | `#27500A` |
| 学术研究 / 营销策略 | `#FAEEDA` | `#633806` |
| 产品发布 / 方法论 | `#EEEDFE` | `#3C3489` |
| 安全预警 / 前沿警示 | `#FCEBEB` | `#791F1F` |
| 行业趋势 / 运营策略 | `#E1F5EE` | `#0F6E56` |

### 数据高亮色

| 场景 | 颜色 |
|------|------|
| 蓝色主题 stat 数字 | `#185FA5` |
| 绿色主题 stat 数字 | `#3B6D11` 或 `#1A7A44` |
| 编辑观点左边框 | `#639922` 或 `#3B6D11` |

---

## CSS 变量（必须使用，禁止硬编码）

```css
var(--font-sans)                    /* 字体族 */
var(--color-text-primary)           /* 主文字色 */
var(--color-text-secondary)         /* 次要文字色 */
var(--color-background-primary)     /* 卡片/主背景 */
var(--color-background-secondary)   /* 次级背景（stat、tool卡） */
var(--color-border-tertiary)        /* 分隔线、卡片边框 */
var(--border-radius-lg)             /* 大圆角（卡片） */
var(--border-radius-md)             /* 中圆角（标签、按钮） */
```

---

## 排版规范

| 元素 | 字号 | 字重 | 行高 |
|------|------|------|------|
| Header 主标题 | 22px | 500 | 1.35 |
| 新闻标题 | 14px | 500 | 1.4 |
| 正文段落 | 13px | 400 | 1.65 |
| 标签文字 | 11px | 400 | — |
| 数据大字 | 20px | 500 | — |
| 工具名称 | 14px | 500 | — |
| 数据说明 | 11px | 400 | 1.4 |
| Footer/说明 | 12px | 400 | — |

---

## 布局组件

### Stat Grid（核心数据三栏）

```css
.sgrid {
  display: grid;
  grid-template-columns: repeat(3, minmax(0,1fr));
  gap: 10px;
}
.sbox {
  background: var(--color-background-secondary);
  border-radius: var(--border-radius-md);
  padding: 12px;
  text-align: center;
}
```

### 新闻卡片

```css
.card {
  background: var(--color-background-primary);
  border: .5px solid var(--color-border-tertiary);
  border-radius: var(--border-radius-lg);
  padding: 14px 16px;
  margin-bottom: 10px;
}
.card-row { display: flex; gap: 10px; }
.num {
  width: 22px; height: 22px;
  border-radius: 50%;
  background: var(--color-background-secondary);
  font-size: 11px; font-weight: 500;
  line-height: 22px; text-align: center;
  flex-shrink: 0; margin-top: 2px;
}
```

### 工具卡片

```css
.tcard {
  background: var(--color-background-secondary);
  border-radius: var(--border-radius-lg);
  padding: 14px 16px;
  margin-bottom: 10px;
  display: flex; gap: 14px; align-items: flex-start;
}
.tico {
  width: 36px; height: 36px;
  border-radius: var(--border-radius-md);
  display: flex; align-items: center; justify-content: center;
  flex-shrink: 0;
}
```

### 编辑观点

```css
.tipbox {
  background: #EAF3DE;
  border-radius: 0 var(--border-radius-md) var(--border-radius-md) 0;
  padding: 14px 16px;
  border-left: 3px solid #3B6D11;
}
```

### Section 标签

```css
.sec {
  font-size: 11px; font-weight: 500;
  letter-spacing: .09em; text-transform: uppercase;
  color: var(--color-text-secondary);
  margin: 24px 0 10px;
  padding-bottom: 6px;
  border-bottom: .5px solid var(--color-border-tertiary);
}
```

### Footer 按钮

```css
.btn {
  font-size: 12px; padding: 6px 14px;
  border-radius: var(--border-radius-md);
  border: .5px solid var(--color-border-secondary);
  background: transparent;
  color: var(--color-text-secondary);
  cursor: pointer;
}
.btn:hover { background: var(--color-background-secondary); }
```

---

## 本周一图 · SVG 规范

- viewBox：`0 0 620 N`（N 根据内容高度调整，通常 150~220）
- 宽度：`style="width:100%;display:block"`
- 颜色：优先使用色彩系统中的标准色值
- 字体：`font-size` 10~12px，`fill` 使用对应色系深色
- 图形类型选择：
  - **对比内容** → 双栏对比表格 SVG
  - **流程/步骤** → 横向流程图（箭头连接）
  - **五维/多维** → 放射状节点图
  - **时间线** → 纵向时间轴
  - **数据分布** → 柱状/面积图

---

## 最大宽度

```css
.nl { max-width: 660px; margin: 0 auto; }
```
